<?php
// ☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎
// CREATED BY WAHYU STORE 🜲
// NOT REEDIT SCRIPT 
// YOUTUBE : WAHYUSTOREID
// INSTAGRAM : whyu_ard1
// WHATSAPP : 6283189912927
// ☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎☠︎︎☠
// Video Utama
$img1 = 'https://i.ibb.co/9gLm3pd/Screenshot-500.png'; // gambar Utama
$judul1 = 'Arachuu Virall Full Video'; //judul Utama
$jumlahview1 = '2,4 jt'; // Jumlah tonton Utama
$tgl1 = '1 mgg lalu'; // Tgl upload Utama
$like1 = '22 rb'; // Jumlah like Utama
$durasi1 = '90.00'; // Durasi video Utama

$gambarch = 'https://i.ibb.co/Hx7X5kq/Screenshot-497.png'; // Gambar Channel
$namach = 'Viral ID'; // Nama Channel
$subsch = '271 rb'; // Subscriber Channel


// Thumbnail 1
$img2 = 'https://i.ibb.co/PmN2bpt/Whats-App-Image-2022-06-16-at-02-07-40.jpg'; // gambar Tumbnail 1
$judul2 = 'Riffa & Atta Tiktok Viral'; //judul Tumbnail 1
$jumlahview2 = '5,1 jt'; // Jumlah tonton Tumbnail 1
$tgl2 = '2 minggu yang lalu'; // Tgl upload Tumbnail 1
$durasi2 = '21.57'; // Durasi Tumbnail 1

$gambarch2 = 'https://i.ibb.co/JsDmVFv/Screenshot-499.png'; // Gambar Channel Thumbnail 1
$namach2 = 'Tiktok Share'; // Nama Channel Thumbnail 1


// Thumbnail 2
$img3 = 'https://i.ibb.co/spfpL3v/Whats-App-Image-2022-06-16-at-02-16-52.jpg'; // gambar Tumbnail 2
$judul3 = 'Abg Masker Ganas || Video 28'; //judul Tumbnail 2
$jumlahview3 = '2,8 jt'; // Jumlah tonton Tumbnail 2
$tgl3 = '1 minggu yang lalu'; // Tgl upload Tumbnail 2
$durasi3 = '40.06'; // Durasi Tumbnail 2

$gambarch3 = 'https://i.ibb.co/7gKKdxV/Screenshot-498.png'; // Gambar Channel Thumbnail 2
$namach3 = 'Suka Becek'; // Nama Channel Thumbnail 2

?>