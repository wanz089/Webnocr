<?php 
$nama = "RESULT LUKY NESIA";
$mailzz = "emailmu@gmail.com";
?>