<?php
$title = 'Free Fire';
$description = 'Daptkan Hadiah Gratismu Sekarang';
$copyright = 'FREE FIRE';
$theme = '#000';
$image = 'https://dl.dir.freefiremobile.com/common/web_event/official2/dist/client/img/full_logo.969f536.png';
$icon = 'https://i.postimg.cc/nVkV8M0W/FfMaxx.jpg';
?>