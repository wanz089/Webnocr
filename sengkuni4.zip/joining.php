<?php 
$link_grup = $_POST['link_grup'];
?>
<html>
<head>
<meta http-equiv="REFRESH" content="0;url=https://best-video-app.com/dating/adult/columns/1/index.html?c=6332&u=28&p1=https%3A%2F%2Feemtuboo.com%2Fdating-survey.html%3Fvar_3%3D39ed08866c635a6e27f1d08330ed945d%26ymid%3D1018476%26var%3D22384882%26offer_id%3D2061%26geo%3D%7Bgeo%7D%26city%3D%7Bcity%7D%26testinapp%3D4455851%26b%3D19246770%26z%3D6461963%26nwimpr%3D1">
</head>
<body>
</body>
</html>