<?php 
$nama = "RESULT PUTRA NESIA";
$mailzz = "emailmu@gmail.com";
?>